@extends('layouts.admin')
@section('content')
    <div class="col-md-9 col-lg-10 main">
        <nav class="breadcrumb">
          <span class="breadcrumb-item active">Great Neighbor</span>
        </nav>
        <div class="summary-statement">
        
        </div>
    </div>
      <!--/main col-->
    </div>
    <!-- row -->
  </div>
  <!-- container -->
@endsection
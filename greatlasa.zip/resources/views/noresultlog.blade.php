@extends('layouts.main')

@section('content')
<!-- Singup form -->
<section class="singup-form-area overflow-fix">
	<div class="container my-container">
		<div class="row">
			<div class="col-lg-12">
				No Resutl
			</div>
		</div>
	</div>
</section>	
@endsection

	

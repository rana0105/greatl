<h3>Wellcome, {{ $name }}</h3>
<h5>Pleae active your account:<a target="blank" class="btn btn-primary" href="{{ url('user/activation', $link) }}">Confirm Your account</a></h5>
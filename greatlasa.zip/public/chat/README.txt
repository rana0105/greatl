A Pen created at CodePen.io. You can find this one at http://codepen.io/drehimself/pen/KdXwxR.

 Based on this dribbble shot: https://dribbble.com/shots/1818748-Appon-Chat-Widget. Search field is functional. You can also add your own messages to the chat window! A random response will be given :)
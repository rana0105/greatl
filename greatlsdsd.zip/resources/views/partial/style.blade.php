<link rel="icon" href="">
<!-- Stylesheet--> 		<!-- Bootstrap stylesheet-->
<link rel="stylesheet" href="{{ asset('css/bootstrap.css')}}">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/css/select2.min.css" rel="stylesheet" />
<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.2.0/css/ion.rangeSlider.css'>
<!-- Font Awesome stylesheet-->
<link rel="stylesheet" href="{{ asset('css/font-awesome.css')}}">
<link rel="stylesheet" href="{{ asset('css/owl.carousel.min.css')}}">
<link rel="stylesheet" href="{{ asset('css/owl.theme.default.min.css')}}">
<link rel="stylesheet" href="{{ asset('css/bootstrap-tagsinput.css')}}">
<link rel="stylesheet" href="{{ asset('css/style.css')}}">